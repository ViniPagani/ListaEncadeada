package listaencadeada;
import java.util.Scanner;

public class ListaEncadeada {
    private Node Lista;
    public ListaEncadeada(){
        this.Lista = null;
    }

    //Inserindo elementos
    public void inserir (int informacao){
        //Declarando nosso novo nó
        Node no = new Node();
        no.setInformacao(informacao);

        if(Lista == null){
            Lista = no;
        }
        else{
            //Aqui se cria um apontador para a lista.
            Node atual = Lista;
            while(atual.getProximo() != null){
                atual = atual.getProximo();
            }
            atual.setProximo(no);
        }
    }


    // Removendo elementos
    public void remover(int informacao) {
        if (Lista == null) {
            System.out.println("A lista está vazia.");
            return;
        }

        Node atual = Lista;
        Node anterior = null;

        do {
            if (atual.getInformacao().equals(informacao)) {
                if (anterior == null) {
                    // Caso especial: o nó a ser removido é o primeiro nó
                    Node ultimo = Lista;
                    while (ultimo.getProximo() != null) {
                        ultimo = ultimo.getProximo();
                    }
                    Lista = Lista.getProximo();
                    ultimo.setProximo(Lista);
                } else {
                    anterior.setProximo(atual.getProximo());
                }

                System.out.println("Elemento removido: " + informacao);
                return;
            }

            anterior = atual;
            atual = atual.getProximo();
        } while (atual != Lista);

        System.out.println("Elemento nao encontrado na lista.");
    }


    //Imprimindo elementos
    public void imprime(){
        if (Lista == null) {
            System.out.println("A lista esta vazia.");
            return;
        }

        Node atual = Lista;
        do {
            System.out.print(atual.getInformacao() + " -> ");
            atual = atual.getProximo();
        } while (atual != null);
        System.out.println("Acabou");
    }


    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    ListaEncadeada lista = new ListaEncadeada();

    while (true) {
        System.out.println("Escolha uma opcao");
        System.out.println("1 - Inserir");
        System.out.println("2 - Excluir");
        System.out.println("0 - Parar");
        System.out.print("Opcao: ");
        int op = scanner.nextInt();
        int item;

        if (op == 1) {
            System.out.println("Insira os elementos (0 para parar):");
            while (true) {
                item = scanner.nextInt();
                if (item == 0) {
                    break;
                }
                lista.inserir(item);
            }
        } else if (op == 2) {
            System.out.println("Indique o elemento a ser removido:");
            item = scanner.nextInt();
            lista.remover(item);
        } else if (op == 0) {
            System.out.println("Lista Encadeada:");
            lista.imprime();
            System.exit(0);
        } else {
            System.out.println("Escolha uma opcao valida");
        }
    }
}

}
